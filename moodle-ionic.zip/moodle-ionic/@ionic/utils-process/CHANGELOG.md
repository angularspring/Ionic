# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

<a name="0.1.0"></a>
# [0.1.0](https://github.com/ionic-team/ionic-cli/compare/@ionic/utils-process@0.0.1...@ionic/utils-process@0.1.0) (2019-03-06)


### Features

* **process:** add `getPathParts` to split path into parts ([7dfbbc2](https://github.com/ionic-team/ionic-cli/commit/7dfbbc2))




<a name="0.0.1"></a>
## 0.0.1 (2019-02-27)




**Note:** Version bump only for package @ionic/utils-process
