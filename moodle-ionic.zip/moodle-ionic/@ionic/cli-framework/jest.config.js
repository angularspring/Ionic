module.exports = require('../../../jest.config.base');
