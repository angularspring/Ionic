# Ionic Lab

Stand-alone Ionic Lab package, a utility used by `ionic serve --lab`.

Once installed, invoke serve on your framework CLI of choice. Then, copy the
URL of that server and invoke the Ionic Lab CLI. For example:

```bash
$ ionic-lab http://localhost:4200
```
