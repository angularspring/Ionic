# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

<a name="0.0.1"></a>
## 0.0.1 (2019-02-27)




**Note:** Version bump only for package @ionic/utils-array
